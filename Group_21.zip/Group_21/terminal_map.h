/*
  GROUP NO. 21
  Authors:
    - Sarthak Sehgal (2017B3A70452P)
    - Syed Ahsan Abbas (2017B3A70507P)
*/

#include "./hash_map.h"

#ifndef TERMINAL_MAP_H
#define TERMINAL_MAP_H

hash_map *generate_t_map(int map_size);

#endif