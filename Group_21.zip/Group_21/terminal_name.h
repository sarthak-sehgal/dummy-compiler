/*
  GROUP NO. 21
  Authors:
    - Sarthak Sehgal (2017B3A70452P)
    - Syed Ahsan Abbas (2017B3A70507P)
*/

#include <string.h>
#include "./entities.h"

#ifndef TERMINAL_NAME_H
#define TERMINAL_NAME_H

void get_t_name(terminal t, char *name);

#endif