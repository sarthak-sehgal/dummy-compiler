/*
  GROUP NO. 21
  Authors:
    - Sarthak Sehgal (2017B3A70452P)
    - Syed Ahsan Abbas (2017B3A70507P)
*/

#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <stdlib.h>

#ifndef GENERAL_H
#define GENERAL_H

void assert(bool condition, char *error_string);

int string_to_num(char *string);

#endif