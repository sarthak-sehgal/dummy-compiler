/*
  GROUP NO. 21
  Authors:
    - Sarthak Sehgal (2017B3A70452P)
    - Syed Ahsan Abbas (2017B3A70507P)
*/

#include "./hash_map.h"

#ifndef NONTERMINAL_MAP_H
#define NONTERMINAL_MAP_H

hash_map *generate_nt_map(int map_size);

#endif